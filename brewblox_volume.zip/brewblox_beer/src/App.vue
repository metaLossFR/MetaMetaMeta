<script src = 'https://unpkg.com/axios/dist/axios.min.js'></script> 
<script src = 'https://unpkg.com/vue'></script>

<template>
  <div id="app">
     <p> <font size="+10">Volume en litre:</font></p>
     <p><font size="+2">{{joke}}</font></p>
     <button @click="actualize()"><font size="+2">Actualiser</font></button>
     
  </div>
</template>
 <script>
 import {mapState} from 'vuex';
 export default{
     name : 'App',
     computed : mapState ([
       'volume'
     ]),
     
     data() {
       return{
         joke : 'a',
       }

     },
     methods:{
        async actualize(){
         let config = {
           headers: {
             'Accept' : 'application/json'
           }
         }
         //LIEN A REMPLACER
         this.joke  = await this.$http.get('http://ron-swanson-quotes.herokuapp.com/v2/quotes')

       }
     }
    
   }

         
 
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
